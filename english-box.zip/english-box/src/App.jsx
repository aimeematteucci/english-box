import { useState, useEffect } from "react";

// ─── CONFIGURATION — edit these to customise your app ────────────────────────
const TEACHER_PASSWORD = "teacher123";   // ← Change this before going live!
const MAX_SPOTS = 5;
const PAYMENT_LINK = "https://paypal.me/yourlink"; // ← Your PayPal / Stripe link

const CLASS_SCHEDULE = [
  { dayOfWeek: 1, time: "13:30", level: "B1",           duration: 60 },
  { dayOfWeek: 2, time: "20:30", level: "B2",           duration: 60 },
  { dayOfWeek: 5, time: "13:30", level: "Conversation", duration: 60 },
];
// ─────────────────────────────────────────────────────────────────────────────

const LEVEL_COLORS = {
  "B1":           { bg: "#2e3d1a", text: "#b8ce82" },
  "B2":           { bg: "#1a1a2e", text: "#a8a0cc" },
  "Conversation": { bg: "#2e2200", text: "#d4a828" },
};

const DAYS   = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const MONTHS = ["January","February","March","April","May","June",
                "July","August","September","October","November","December"];

// ── Storage helpers (localStorage) ──────────────────────────────────────────
function lsGet(key) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; }
  catch { return null; }
}
function lsSet(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

// ── Slot generation ──────────────────────────────────────────────────────────
function generateDefaultSlots() {
  const slots = [];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const end   = new Date(today); end.setMonth(end.getMonth() + 3);
  let id = 1;
  for (let d = new Date(today); d <= end; d.setDate(d.getDate() + 1)) {
    const match = CLASS_SCHEDULE.find(c => c.dayOfWeek === d.getDay());
    if (match) slots.push({
      id: String(id++),
      date: d.toISOString().split("T")[0],
      time: match.time, duration: match.duration, level: match.level,
      bookedBy: [],
    });
  }
  return slots;
}

function formatDate(dateStr) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return `${DAYS[dt.getDay()]}, ${MONTHS[m - 1]} ${d}`;
}

function getWeekDays(ws) {
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(ws); d.setDate(ws.getDate() + i); return d;
  });
}

// ── Styles ───────────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Outfit:wght@300;400;500;600&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --black: #0e0e0e; --dark: #161616; --g1: #1e1e1e; --g2: #2a2a2a; --g3: #3d3d3d;
    --g4: #6b6b6b; --g5: #a0a0a0; --g6: #d8d8d8; --white: #f0f0f0;
    --olive: #6b7c45; --olive2: #8a9e58; --oliveL: #c2d490;
    --gold: #c8a028; --gold2: #d4b44a; --goldL: #f0d87a;
    --border: #252525; --red: #c84040;
  }
  html, body, #root { min-height: 100vh; }
  body { font-family: 'Outfit', sans-serif; background: var(--black); color: var(--white); }
  h1, h2, h3 { font-family: 'Cormorant Garamond', serif; }
  input, select, button { font-family: 'Outfit', sans-serif; }
  ::-webkit-scrollbar { width: 5px; }
  ::-webkit-scrollbar-track { background: var(--dark); }
  ::-webkit-scrollbar-thumb { background: var(--g3); border-radius: 3px; }
  input::placeholder { color: var(--g4); }
  input:focus, select:focus { outline: none; border-color: var(--gold) !important; }
`;

// ── Component ────────────────────────────────────────────────────────────────
export default function App() {
  const [view,           setView]           = useState("login");
  const [studentName,    setStudentName]    = useState("");
  const [studentEmail,   setStudentEmail]   = useState("");
  const [teacherPass,    setTeacherPass]    = useState("");
  const [slots,          setSlots]          = useState([]);
  const [bookings,       setBookings]       = useState([]);
  const [weekStart,      setWeekStart]      = useState(() => {
    const d = new Date(); d.setHours(0,0,0,0); d.setDate(d.getDate() - d.getDay()); return d;
  });
  const [selectedSlot,   setSelectedSlot]   = useState(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [filterLevel,    setFilterLevel]    = useState("All");
  const [loginError,     setLoginError]     = useState("");
  const [rescheduleModal,  setRescheduleModal]  = useState(null);
  const [rescheduleTarget, setRescheduleTarget] = useState("");
  const [teacherTab,     setTeacherTab]     = useState("bookings");
  const [addForm,        setAddForm]        = useState({ date:"", time:"13:30", level:"B1", duration:60 });
  const [addError,       setAddError]       = useState("");

  // Load from localStorage on mount
  useEffect(() => {
    const s = lsGet("eb_slots");
    const b = lsGet("eb_bookings");
    setSlots(s ?? generateDefaultSlots());
    setBookings(b ?? []);
  }, []);

  function saveSlots(s)    { setSlots(s);    lsSet("eb_slots",    s); }
  function saveBookings(b) { setBookings(b); lsSet("eb_bookings", b); }

  // ── Auth ──
  function handleStudentLogin(e) {
    e.preventDefault();
    if (!studentName.trim() || !studentEmail.trim()) { setLoginError("Please enter your name and email."); return; }
    if (!studentEmail.includes("@"))                 { setLoginError("Enter a valid email."); return; }
    setLoginError(""); setView("student");
  }
  function handleTeacherLogin(e) {
    e.preventDefault();
    if (teacherPass === TEACHER_PASSWORD) { setView("teacher"); setLoginError(""); }
    else setLoginError("Incorrect password.");
  }

  // ── Booking ──
  function handleBook(slot) {
    if (bookings.find(b => b.slotId === slot.id && b.email === studentEmail)) { alert("You already booked this class!"); return; }
    if (slot.bookedBy.length >= MAX_SPOTS) { alert("Sorry, this class is full."); return; }
    const ns = slots.map(s => s.id === slot.id ? { ...s, bookedBy: [...s.bookedBy, { name: studentName, email: studentEmail }] } : s);
    const nb = [...bookings, { id: Date.now().toString(), slotId: slot.id, name: studentName, email: studentEmail, paid: false, date: slot.date, time: slot.time, duration: slot.duration, level: slot.level }];
    saveSlots(ns); saveBookings(nb);
    setSelectedSlot(null); setBookingSuccess(true);
    setTimeout(() => setBookingSuccess(false), 6000);
    window.open(PAYMENT_LINK, "_blank");
  }

  // ── Reschedule ──
  function handleReschedule() {
    if (!rescheduleTarget) return;
    const bk = rescheduleModal;
    const newSlot = slots.find(s => s.id === rescheduleTarget);
    if (!newSlot || newSlot.bookedBy.length >= MAX_SPOTS) { alert("That slot is full or invalid."); return; }
    const us = slots.map(s => {
      if (s.id === bk.slotId)        return { ...s, bookedBy: s.bookedBy.filter(b => b.email !== bk.email) };
      if (s.id === rescheduleTarget) return { ...s, bookedBy: [...s.bookedBy, { name: bk.name, email: bk.email }] };
      return s;
    });
    const ub = bookings.map(b => b.id === bk.id
      ? { ...b, slotId: rescheduleTarget, date: newSlot.date, time: newSlot.time, duration: newSlot.duration, level: newSlot.level }
      : b);
    saveSlots(us); saveBookings(ub);
    setRescheduleModal(null); setRescheduleTarget("");
  }

  function togglePaid(id) {
    saveBookings(bookings.map(b => b.id === id ? { ...b, paid: !b.paid } : b));
  }

  // ── Add / Remove slots ──
  function handleAddSlot(e) {
    e.preventDefault(); setAddError("");
    if (!addForm.date) { setAddError("Please pick a date."); return; }
    if (slots.find(s => s.date === addForm.date && s.time === addForm.time)) { setAddError("A slot at this date/time already exists."); return; }
    const ns = { id: Date.now().toString(), date: addForm.date, time: addForm.time, level: addForm.level, duration: Number(addForm.duration), bookedBy: [] };
    saveSlots([...slots, ns].sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time)));
    setAddForm({ date: "", time: "13:30", level: "B1", duration: 60 });
  }

  function handleRemoveSlot(slotId) {
    const has = bookings.some(b => b.slotId === slotId);
    if (has && !confirm("This slot has bookings. Remove it anyway?")) return;
    saveSlots(slots.filter(s => s.id !== slotId));
    if (has) saveBookings(bookings.filter(b => b.slotId !== slotId));
  }

  // ── Derived ──
  const weekDays  = getWeekDays(weekStart);
  const todayStr  = new Date().toISOString().split("T")[0];
  const weekSlots = slots.filter(s => {
    const d = new Date(s.date + "T00:00:00");
    return d >= weekStart && d < new Date(weekStart.getTime() + 7 * 86400000);
  });
  const myBookings = bookings.filter(b => b.email === studentEmail);

  // ── Shared input style ──
  const inp = { padding:"0.65rem 0.85rem", borderRadius:"0.45rem", border:"1px solid var(--g2)", background:"var(--g1)", color:"var(--white)", fontSize:"0.85rem", width:"100%" };
  const sel = { ...inp, cursor:"pointer" };

  // ════════════════════════════════════════════════════════════════════════════
  //  LOGIN
  // ════════════════════════════════════════════════════════════════════════════
  if (view === "login") return (
    <>
      <style>{css}</style>
      <div style={{ minHeight:"100vh", background:"var(--black)", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"2rem", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", inset:0, background:"radial-gradient(ellipse 70% 50% at 50% 0%, rgba(107,124,69,0.10) 0%, transparent 70%)", pointerEvents:"none" }}/>
        <div style={{ position:"absolute", bottom:0, left:0, right:0, height:"1px", background:"linear-gradient(90deg, transparent, var(--gold), transparent)" }}/>

        <div style={{ textAlign:"center", marginBottom:"2.8rem", position:"relative" }}>
          <div style={{ display:"inline-block", border:"1px solid rgba(200,160,40,0.4)", borderRadius:"0.35rem", padding:"0.25rem 0.9rem", fontSize:"0.65rem", color:"var(--gold2)", letterSpacing:"2.5px", textTransform:"uppercase", marginBottom:"1.1rem" }}>Online English Classes</div>
          <h1 style={{ fontSize:"3.2rem", color:"var(--white)", letterSpacing:"-1.5px", lineHeight:1 }}>
            English <span style={{ color:"var(--gold)" }}>Box</span>
          </h1>
          <p style={{ color:"var(--g5)", marginTop:"0.6rem", fontSize:"0.9rem", letterSpacing:"1.5px", textTransform:"uppercase" }}>Teacher Aimee</p>
          <div style={{ width:"40px", height:"1px", background:"var(--gold)", margin:"1rem auto 0", opacity:0.4 }}/>
        </div>

        <div style={{ display:"flex", gap:"1.2rem", flexWrap:"wrap", justifyContent:"center", width:"100%", maxWidth:"660px", position:"relative" }}>
          {/* Student card */}
          <div style={{ flex:1, minWidth:"270px", background:"var(--dark)", borderRadius:"0.9rem", padding:"1.8rem", border:"1px solid var(--border)" }}>
            <div style={{ display:"flex", alignItems:"center", gap:"0.5rem", marginBottom:"1.3rem" }}>
              <div style={{ width:"7px", height:"7px", borderRadius:"50%", background:"var(--olive2)" }}/>
              <h2 style={{ fontSize:"1.05rem", color:"var(--white)" }}>Student Access</h2>
            </div>
            <form onSubmit={handleStudentLogin} style={{ display:"flex", flexDirection:"column", gap:"0.7rem" }}>
              <input placeholder="Your full name"  value={studentName}  onChange={e => setStudentName(e.target.value)}  style={inp}/>
              <input placeholder="Email address" type="email" value={studentEmail} onChange={e => setStudentEmail(e.target.value)} style={inp}/>
              <button type="submit" style={{ padding:"0.7rem", borderRadius:"0.45rem", background:"var(--olive)", color:"#fff", border:"none", fontSize:"0.88rem", fontWeight:600, cursor:"pointer" }}>View Classes →</button>
            </form>
            {loginError && view !== "teacher" && <p style={{ color:"#e07070", fontSize:"0.78rem", marginTop:"0.5rem" }}>{loginError}</p>}
          </div>

          {/* Teacher card */}
          <div style={{ flex:1, minWidth:"270px", background:"var(--dark)", borderRadius:"0.9rem", padding:"1.8rem", border:"1px solid rgba(200,160,40,0.3)", boxShadow:"0 0 40px rgba(200,160,40,0.04)" }}>
            <div style={{ display:"flex", alignItems:"center", gap:"0.5rem", marginBottom:"1.3rem" }}>
              <div style={{ width:"7px", height:"7px", borderRadius:"50%", background:"var(--gold)" }}/>
              <h2 style={{ fontSize:"1.05rem", color:"var(--white)" }}>Teacher Access</h2>
            </div>
            <form onSubmit={handleTeacherLogin} style={{ display:"flex", flexDirection:"column", gap:"0.7rem" }}>
              <input placeholder="Password" type="password" value={teacherPass} onChange={e => { setTeacherPass(e.target.value); setLoginError(""); }} style={inp}/>
              <button type="submit" style={{ padding:"0.7rem", borderRadius:"0.45rem", background:"var(--gold)", color:"var(--black)", border:"none", fontSize:"0.88rem", fontWeight:700, cursor:"pointer" }}>Go to Dashboard →</button>
            </form>
            {loginError && <p style={{ color:"#e07070", fontSize:"0.78rem", marginTop:"0.5rem" }}>{loginError}</p>}
          </div>
        </div>

        <div style={{ display:"flex", gap:"1.2rem", marginTop:"2.5rem", flexWrap:"wrap", justifyContent:"center" }}>
          {[["Mon","B1 class","var(--oliveL)"],["Tue","B2 class","#a8a0cc"],["Fri","Conversation","var(--goldL)"]].map(([d,l,c]) => (
            <div key={d} style={{ display:"flex", alignItems:"center", gap:"0.4rem", fontSize:"0.75rem", color:"var(--g5)" }}>
              <div style={{ width:"7px", height:"7px", borderRadius:"50%", background:c }}/>
              {d} · {l}
            </div>
          ))}
        </div>
      </div>
    </>
  );

  // ════════════════════════════════════════════════════════════════════════════
  //  STUDENT
  // ════════════════════════════════════════════════════════════════════════════
  if (view === "student") return (
    <>
      <style>{css}</style>
      <div style={{ minHeight:"100vh", background:"var(--black)" }}>

        {/* Header */}
        <div style={{ background:"var(--dark)", borderBottom:"1px solid var(--border)", padding:"1rem 2rem", display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"0.5rem" }}>
          <div>
            <h1 style={{ fontSize:"1.35rem", color:"var(--white)" }}>English <span style={{ color:"var(--gold)" }}>Box</span></h1>
            <p style={{ color:"var(--g4)", fontSize:"0.75rem" }}>Teacher Aimee · {studentName}</p>
          </div>
          <div style={{ display:"flex", gap:"0.75rem", alignItems:"center" }}>
            {myBookings.length > 0 && <span style={{ background:"var(--olive)", color:"#fff", borderRadius:"2rem", padding:"0.25rem 0.7rem", fontSize:"0.75rem", fontWeight:600 }}>{myBookings.length} booked</span>}
            <button onClick={() => { setView("login"); setStudentName(""); setStudentEmail(""); }} style={{ padding:"0.35rem 0.75rem", borderRadius:"0.4rem", background:"transparent", border:"1px solid var(--border)", color:"var(--g5)", cursor:"pointer", fontSize:"0.78rem" }}>Log out</button>
          </div>
        </div>

        <div style={{ maxWidth:"960px", margin:"0 auto", padding:"2rem 1.5rem" }}>

          {/* Success banner */}
          {bookingSuccess && (
            <div style={{ background:"rgba(107,124,69,0.12)", border:"1px solid var(--olive)", borderRadius:"0.65rem", padding:"0.9rem 1.2rem", marginBottom:"1.5rem", display:"flex", gap:"0.7rem" }}>
              <span style={{ color:"var(--oliveL)", fontWeight:600 }}>✓</span>
              <div>
                <p style={{ color:"var(--oliveL)", fontWeight:600, fontSize:"0.88rem" }}>Class booked!</p>
                <p style={{ color:"var(--g5)", fontSize:"0.78rem" }}>The payment page has opened. Your spot is confirmed once Teacher Aimee receives your payment.</p>
              </div>
            </div>
          )}

          {/* My bookings */}
          {myBookings.length > 0 && (
            <div style={{ marginBottom:"2.5rem" }}>
              <h2 style={{ fontSize:"1.2rem", color:"var(--white)", marginBottom:"1rem" }}>My Bookings</h2>
              <div style={{ display:"flex", flexWrap:"wrap", gap:"0.65rem" }}>
                {myBookings.map(b => {
                  const lc = LEVEL_COLORS[b.level] || {};
                  return (
                    <div key={b.id} style={{ background:"var(--dark)", border:"1px solid var(--border)", borderRadius:"0.7rem", padding:"0.9rem 1.1rem", minWidth:"190px" }}>
                      <span style={{ background:lc.bg, color:lc.text, borderRadius:"0.25rem", padding:"0.1rem 0.45rem", fontSize:"0.68rem", fontWeight:700, display:"inline-block", marginBottom:"0.4rem" }}>{b.level}</span>
                      <p style={{ fontWeight:600, fontSize:"0.88rem", color:"var(--white)" }}>{formatDate(b.date)}</p>
                      <p style={{ color:"var(--g5)", fontSize:"0.78rem" }}>{b.time} · {b.duration}min</p>
                      <div style={{ display:"flex", alignItems:"center", gap:"0.45rem", marginTop:"0.5rem" }}>
                        <span style={{ fontSize:"0.7rem", padding:"0.12rem 0.45rem", borderRadius:"1rem", background:b.paid ? "rgba(107,124,69,0.2)" : "rgba(200,160,40,0.1)", color:b.paid ? "var(--oliveL)" : "var(--gold2)", fontWeight:600 }}>
                          {b.paid ? "✓ Paid" : "⏳ Pending"}
                        </span>
                        {!b.paid && <a href={PAYMENT_LINK} target="_blank" rel="noopener noreferrer" style={{ fontSize:"0.72rem", color:"var(--gold)", textDecoration:"underline" }}>Pay →</a>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Calendar controls */}
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"1.2rem", flexWrap:"wrap", gap:"0.75rem" }}>
            <h2 style={{ fontSize:"1.2rem", color:"var(--white)" }}>Available Classes</h2>
            <div style={{ display:"flex", gap:"0.4rem", alignItems:"center", flexWrap:"wrap" }}>
              <select value={filterLevel} onChange={e => setFilterLevel(e.target.value)} style={{ ...sel, width:"auto", padding:"0.38rem 0.65rem", fontSize:"0.8rem" }}>
                <option value="All">All classes</option>
                <option>B1</option><option>B2</option><option>Conversation</option>
              </select>
              <button onClick={() => setWeekStart(d => { const n=new Date(d); n.setDate(d.getDate()-7); return n; })} style={{ padding:"0.38rem 0.65rem", borderRadius:"0.4rem", border:"1px solid var(--g2)", background:"var(--dark)", color:"var(--g5)", cursor:"pointer", fontSize:"0.82rem" }}>←</button>
              <span style={{ fontSize:"0.82rem", color:"var(--g5)", minWidth:"100px", textAlign:"center" }}>{MONTHS[weekStart.getMonth()].slice(0,3)} {weekStart.getFullYear()}</span>
              <button onClick={() => setWeekStart(d => { const n=new Date(d); n.setDate(d.getDate()+7); return n; })} style={{ padding:"0.38rem 0.65rem", borderRadius:"0.4rem", border:"1px solid var(--g2)", background:"var(--dark)", color:"var(--g5)", cursor:"pointer", fontSize:"0.82rem" }}>→</button>
            </div>
          </div>

          {/* Week grid */}
          <div style={{ display:"grid", gridTemplateColumns:"repeat(7, 1fr)", gap:"0.45rem" }}>
            {weekDays.map(day => {
              const ds        = day.toISOString().split("T")[0];
              const daySlots  = weekSlots.filter(s => s.date === ds && (filterLevel === "All" || s.level === filterLevel));
              const isPast    = ds < todayStr;
              const isToday   = ds === todayStr;
              return (
                <div key={ds}>
                  <div style={{ textAlign:"center", marginBottom:"0.5rem" }}>
                    <div style={{ fontSize:"0.6rem", color:"var(--g4)", textTransform:"uppercase", letterSpacing:"0.3px" }}>{DAYS[day.getDay()]}</div>
                    <div style={{ fontSize:"0.9rem", fontWeight:600, color:isToday?"var(--gold)":"var(--g6)", width:"24px", height:"24px", borderRadius:"50%", background:isToday?"rgba(200,160,40,0.12)":"transparent", display:"flex", alignItems:"center", justifyContent:"center", margin:"0.15rem auto 0" }}>
                      {day.getDate()}
                    </div>
                  </div>
                  {daySlots.map(slot => {
                    const avail = MAX_SPOTS - slot.bookedBy.length;
                    const full  = avail === 0;
                    const isMine = slot.bookedBy.some(b => b.email === studentEmail);
                    const lc = LEVEL_COLORS[slot.level] || {};
                    return (
                      <button key={slot.id}
                        onClick={() => !isPast && !full && !isMine && setSelectedSlot(slot)}
                        style={{ width:"100%", marginBottom:"0.3rem", padding:"0.4rem 0.28rem", borderRadius:"0.4rem", border:`1px solid ${isMine?"var(--olive)":full?"var(--g3)":"var(--g2)"}`, background:isMine?"rgba(107,124,69,0.18)":full?"rgba(20,20,20,0.6)":"var(--dark)", cursor:full||isPast||isMine?"default":"pointer", opacity:isPast?0.35:1, textAlign:"left" }}>
                        <div style={{ fontSize:"0.67rem", fontWeight:600, color:isMine?"var(--oliveL)":full?"var(--g4)":"var(--white)" }}>{slot.time}</div>
                        <div style={{ fontSize:"0.58rem", color:lc.text||"var(--g5)", marginTop:"0.05rem" }}>{slot.level}</div>
                        <div style={{ fontSize:"0.57rem", color:isMine?"var(--oliveL)":full?"var(--red)":"var(--gold)", marginTop:"0.1rem", fontWeight:500 }}>{isMine?"✓ yours":full?"Full":`${avail} left`}</div>
                      </button>
                    );
                  })}
                  {daySlots.length === 0 && <div style={{ height:"38px", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"0.65rem", color:"var(--g2)" }}>—</div>}
                </div>
              );
            })}
          </div>
          <div style={{ marginTop:"1rem", display:"flex", gap:"1.2rem", flexWrap:"wrap", fontSize:"0.72rem", color:"var(--g4)" }}>
            <span><span style={{ color:"var(--gold)" }}>■</span> available</span>
            <span><span style={{ color:"var(--oliveL)" }}>■</span> your booking</span>
            <span><span style={{ color:"var(--red)" }}>■</span> full</span>
          </div>
        </div>

        {/* Booking modal */}
        {selectedSlot && (
          <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:100, padding:"1rem" }}>
            <div style={{ background:"var(--dark)", borderRadius:"1rem", padding:"2rem", maxWidth:"390px", width:"100%", border:"1px solid var(--g2)", boxShadow:"0 20px 60px rgba(0,0,0,0.5)" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"1.2rem" }}>
                <div>
                  <h2 style={{ fontSize:"1.5rem", color:"var(--white)" }}>Book Class</h2>
                  <p style={{ color:"var(--g4)", fontSize:"0.78rem" }}>Confirm & go to payment</p>
                </div>
                <span style={{ background:(LEVEL_COLORS[selectedSlot.level]||{}).bg, color:(LEVEL_COLORS[selectedSlot.level]||{}).text, borderRadius:"0.35rem", padding:"0.2rem 0.55rem", fontSize:"0.78rem", fontWeight:700 }}>{selectedSlot.level}</span>
              </div>
              <div style={{ background:"var(--g1)", borderRadius:"0.65rem", padding:"0.9rem 1.1rem", marginBottom:"1.3rem", display:"flex", flexDirection:"column", gap:"0.45rem" }}>
                <Row label="Date"       value={formatDate(selectedSlot.date)} />
                <Row label="Time"       value={selectedSlot.time} />
                <Row label="Duration"   value={`${selectedSlot.duration} min`} />
                <Row label="Spots left" value={`${MAX_SPOTS - selectedSlot.bookedBy.length} / ${MAX_SPOTS}`} />
              </div>
              <p style={{ fontSize:"0.75rem", color:"var(--g4)", marginBottom:"1.2rem" }}>You'll be redirected to the payment page. Your spot is confirmed once Teacher Aimee marks your payment.</p>
              <div style={{ display:"flex", gap:"0.7rem" }}>
                <button onClick={() => setSelectedSlot(null)} style={{ flex:1, padding:"0.7rem", borderRadius:"0.5rem", border:"1px solid var(--g2)", background:"transparent", cursor:"pointer", fontSize:"0.85rem", color:"var(--g5)" }}>Cancel</button>
                <button onClick={() => handleBook(selectedSlot)} style={{ flex:2, padding:"0.7rem", borderRadius:"0.5rem", background:"var(--gold)", color:"var(--black)", border:"none", cursor:"pointer", fontSize:"0.88rem", fontWeight:700 }}>Book & Pay →</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );

  // ════════════════════════════════════════════════════════════════════════════
  //  TEACHER DASHBOARD
  // ════════════════════════════════════════════════════════════════════════════
  return (
    <>
      <style>{css}</style>
      <div style={{ minHeight:"100vh", background:"var(--black)" }}>

        {/* Header */}
        <div style={{ background:"var(--dark)", borderBottom:"1px solid var(--border)", padding:"1rem 2rem", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <h1 style={{ fontSize:"1.3rem", color:"var(--white)" }}>English <span style={{ color:"var(--gold)" }}>Box</span> <span style={{ color:"var(--g4)", fontFamily:"'Outfit',sans-serif", fontSize:"0.85rem", fontWeight:400 }}>· Dashboard</span></h1>
            <p style={{ color:"var(--g4)", fontSize:"0.72rem" }}>Teacher Aimee</p>
          </div>
          <button onClick={() => setView("login")} style={{ padding:"0.35rem 0.75rem", borderRadius:"0.4rem", background:"transparent", border:"1px solid var(--g2)", color:"var(--g5)", cursor:"pointer", fontSize:"0.78rem" }}>Log out</button>
        </div>

        {/* Stats */}
        <div style={{ display:"flex", gap:"1rem", padding:"1.5rem 2rem", flexWrap:"wrap", maxWidth:"1000px", margin:"0 auto" }}>
          {[
            { label:"Total Bookings",    val:bookings.length,                                       accent:"var(--gold)"   },
            { label:"Confirmed Paid",    val:bookings.filter(b => b.paid).length,                   accent:"var(--olive2)" },
            { label:"Awaiting Payment",  val:bookings.filter(b => !b.paid).length,                  accent:"#c88040"       },
            { label:"Unique Students",   val:new Set(bookings.map(b => b.email)).size,              accent:"var(--g6)"     },
          ].map(s => (
            <div key={s.label} style={{ flex:1, minWidth:"130px", background:"var(--dark)", borderRadius:"0.65rem", padding:"1rem 1.1rem", border:"1px solid var(--border)" }}>
              <div style={{ fontSize:"1.9rem", fontWeight:700, color:s.accent, fontFamily:"'Cormorant Garamond', serif" }}>{s.val}</div>
              <div style={{ fontSize:"0.72rem", color:"var(--g4)", marginTop:"0.1rem" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ maxWidth:"1000px", margin:"0 auto", padding:"0 2rem 3rem" }}>
          <div style={{ display:"flex", gap:0, marginBottom:"1.5rem", borderBottom:"1px solid var(--border)" }}>
            {[["bookings","Bookings"],["schedule","Schedule"],["manage","Manage Slots"]].map(([t, label]) => (
              <button key={t} onClick={() => setTeacherTab(t)}
                style={{ padding:"0.6rem 1.2rem", background:"transparent", border:"none", borderBottom:`2px solid ${teacherTab===t?"var(--gold)":"transparent"}`, color:teacherTab===t?"var(--gold)":"var(--g4)", cursor:"pointer", fontSize:"0.85rem", fontWeight:500, marginBottom:"-1px" }}>
                {label}
              </button>
            ))}
          </div>

          {/* — BOOKINGS — */}
          {teacherTab === "bookings" && (
            <div>
              {bookings.length === 0
                ? <p style={{ color:"var(--g4)" }}>No bookings yet.</p>
                : (
                  <div style={{ display:"flex", flexDirection:"column", gap:"0.55rem" }}>
                    {[...bookings].sort((a,b) => a.date.localeCompare(b.date)).map(b => {
                      const lc = LEVEL_COLORS[b.level] || {};
                      return (
                        <div key={b.id} style={{ background:"var(--dark)", borderRadius:"0.65rem", padding:"0.85rem 1.1rem", border:"1px solid var(--border)", display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"0.75rem" }}>
                          <div style={{ display:"flex", gap:"0.65rem", alignItems:"center", flexWrap:"wrap" }}>
                            <span style={{ background:lc.bg, color:lc.text, borderRadius:"0.25rem", padding:"0.1rem 0.4rem", fontSize:"0.68rem", fontWeight:700, whiteSpace:"nowrap" }}>{b.level}</span>
                            <div>
                              <p style={{ fontWeight:600, fontSize:"0.88rem", color:"var(--white)" }}>{b.name} <span style={{ color:"var(--g4)", fontWeight:400, fontSize:"0.78rem" }}>({b.email})</span></p>
                              <p style={{ color:"var(--g4)", fontSize:"0.75rem" }}>{formatDate(b.date)} · {b.time} · {b.duration}min</p>
                            </div>
                          </div>
                          <div style={{ display:"flex", gap:"0.45rem", alignItems:"center", flexWrap:"wrap" }}>
                            <button onClick={() => togglePaid(b.id)} style={{ padding:"0.28rem 0.65rem", borderRadius:"1rem", border:"none", cursor:"pointer", fontSize:"0.72rem", fontWeight:600, background:b.paid?"rgba(107,124,69,0.22)":"rgba(200,160,40,0.12)", color:b.paid?"var(--oliveL)":"var(--gold2)" }}>
                              {b.paid ? "✓ Paid" : "Mark Paid"}
                            </button>
                            <button onClick={() => { setRescheduleModal(b); setRescheduleTarget(""); }} style={{ padding:"0.28rem 0.65rem", borderRadius:"1rem", border:"1px solid var(--g2)", background:"transparent", cursor:"pointer", fontSize:"0.72rem", color:"var(--g5)" }}>
                              ↺ Reschedule
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
            </div>
          )}

          {/* — SCHEDULE — */}
          {teacherTab === "schedule" && (
            <div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"1rem", flexWrap:"wrap", gap:"0.5rem" }}>
                <p style={{ color:"var(--g4)", fontSize:"0.8rem" }}>Weekly overview — all upcoming slots</p>
                <div style={{ display:"flex", gap:"0.4rem" }}>
                  <button onClick={() => setWeekStart(d => { const n=new Date(d); n.setDate(d.getDate()-7); return n; })} style={{ padding:"0.35rem 0.65rem", borderRadius:"0.4rem", border:"1px solid var(--g2)", background:"var(--dark)", color:"var(--g5)", cursor:"pointer", fontSize:"0.78rem" }}>←</button>
                  <span style={{ fontSize:"0.82rem", color:"var(--g5)", padding:"0.35rem 0.4rem" }}>{MONTHS[weekStart.getMonth()].slice(0,3)} {weekStart.getFullYear()}</span>
                  <button onClick={() => setWeekStart(d => { const n=new Date(d); n.setDate(d.getDate()+7); return n; })} style={{ padding:"0.35rem 0.65rem", borderRadius:"0.4rem", border:"1px solid var(--g2)", background:"var(--dark)", color:"var(--g5)", cursor:"pointer", fontSize:"0.78rem" }}>→</button>
                </div>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(7, 1fr)", gap:"0.45rem" }}>
                {weekDays.map(day => {
                  const ds       = day.toISOString().split("T")[0];
                  const daySlots = weekSlots.filter(s => s.date === ds);
                  const isToday  = ds === todayStr;
                  return (
                    <div key={ds}>
                      <div style={{ textAlign:"center", marginBottom:"0.4rem" }}>
                        <div style={{ fontSize:"0.6rem", color:"var(--g4)", textTransform:"uppercase" }}>{DAYS[day.getDay()]}</div>
                        <div style={{ fontSize:"0.88rem", fontWeight:600, color:isToday?"var(--gold)":"var(--g6)" }}>{day.getDate()}</div>
                      </div>
                      {daySlots.map(slot => {
                        const lc   = LEVEL_COLORS[slot.level] || {};
                        const full = slot.bookedBy.length >= MAX_SPOTS;
                        return (
                          <div key={slot.id} style={{ marginBottom:"0.3rem", background:"var(--dark)", borderRadius:"0.4rem", padding:"0.38rem 0.3rem", border:`1px solid ${full?"rgba(200,64,64,0.4)":"var(--border)"}`, fontSize:"0.65rem" }}>
                            <div style={{ fontWeight:600, color:"var(--white)" }}>{slot.time}</div>
                            <div style={{ color:lc.text||"var(--g5)" }}>{slot.level}</div>
                            <div style={{ color:full?"var(--red)":"var(--olive2)", fontWeight:500 }}>{slot.bookedBy.length}/{MAX_SPOTS}</div>
                          </div>
                        );
                      })}
                      {daySlots.length === 0 && <div style={{ height:"36px", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"0.6rem", color:"var(--g2)" }}>—</div>}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* — MANAGE SLOTS — */}
          {teacherTab === "manage" && (
            <div style={{ display:"flex", gap:"2rem", flexWrap:"wrap", alignItems:"flex-start" }}>
              {/* Add slot form */}
              <div style={{ flex:"0 0 260px", background:"var(--dark)", borderRadius:"0.8rem", padding:"1.4rem", border:"1px solid var(--border)" }}>
                <h3 style={{ fontSize:"1rem", color:"var(--white)", marginBottom:"1.1rem" }}>Add New Slot</h3>
                <form onSubmit={handleAddSlot} style={{ display:"flex", flexDirection:"column", gap:"0.65rem" }}>
                  {[
                    { label:"Date",       type:"date",  key:"date",     inputStyle:inp },
                    { label:"Time",       type:"time",  key:"time",     inputStyle:inp },
                  ].map(({ label, type, key, inputStyle }) => (
                    <div key={key}>
                      <label style={{ fontSize:"0.72rem", color:"var(--g4)", display:"block", marginBottom:"0.25rem" }}>{label}</label>
                      <input type={type} value={addForm[key]} onChange={e => setAddForm(f => ({ ...f, [key]: e.target.value }))} style={inputStyle}/>
                    </div>
                  ))}
                  <div>
                    <label style={{ fontSize:"0.72rem", color:"var(--g4)", display:"block", marginBottom:"0.25rem" }}>Class Type</label>
                    <select value={addForm.level} onChange={e => setAddForm(f => ({ ...f, level: e.target.value }))} style={sel}>
                      <option>B1</option><option>B2</option><option>Conversation</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize:"0.72rem", color:"var(--g4)", display:"block", marginBottom:"0.25rem" }}>Duration</label>
                    <select value={addForm.duration} onChange={e => setAddForm(f => ({ ...f, duration: e.target.value }))} style={sel}>
                      <option value={30}>30 min</option><option value={45}>45 min</option><option value={60}>60 min</option><option value={90}>90 min</option>
                    </select>
                  </div>
                  {addError && <p style={{ color:"#e07070", fontSize:"0.75rem" }}>{addError}</p>}
                  <button type="submit" style={{ padding:"0.65rem", borderRadius:"0.45rem", background:"var(--gold)", color:"var(--black)", border:"none", fontWeight:700, fontSize:"0.85rem", cursor:"pointer" }}>+ Add Slot</button>
                </form>
              </div>

              {/* Slot list */}
              <div style={{ flex:1, minWidth:"270px" }}>
                <h3 style={{ fontSize:"1rem", color:"var(--white)", marginBottom:"0.9rem" }}>
                  Upcoming Slots <span style={{ color:"var(--g4)", fontFamily:"'Outfit',sans-serif", fontSize:"0.78rem", fontWeight:400 }}>({slots.filter(s => s.date >= todayStr).length})</span>
                </h3>
                <div style={{ display:"flex", flexDirection:"column", gap:"0.45rem", maxHeight:"460px", overflowY:"auto", paddingRight:"0.25rem" }}>
                  {slots.filter(s => s.date >= todayStr)
                    .sort((a,b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))
                    .map(slot => {
                      const lc = LEVEL_COLORS[slot.level] || {};
                      return (
                        <div key={slot.id} style={{ background:"var(--dark)", borderRadius:"0.55rem", padding:"0.65rem 0.9rem", border:"1px solid var(--border)", display:"flex", justifyContent:"space-between", alignItems:"center", gap:"0.75rem" }}>
                          <div style={{ display:"flex", gap:"0.55rem", alignItems:"center" }}>
                            <span style={{ background:lc.bg, color:lc.text, borderRadius:"0.25rem", padding:"0.1rem 0.4rem", fontSize:"0.65rem", fontWeight:700, whiteSpace:"nowrap" }}>{slot.level}</span>
                            <div>
                              <p style={{ fontSize:"0.8rem", color:"var(--white)", fontWeight:500 }}>{formatDate(slot.date)} · {slot.time}</p>
                              <p style={{ fontSize:"0.7rem", color:"var(--g4)" }}>{slot.duration}min · {slot.bookedBy.length}/{MAX_SPOTS} booked</p>
                            </div>
                          </div>
                          <button onClick={() => handleRemoveSlot(slot.id)} style={{ padding:"0.22rem 0.55rem", borderRadius:"0.35rem", border:"1px solid rgba(200,64,64,0.3)", background:"transparent", color:"var(--red)", cursor:"pointer", fontSize:"0.72rem", flexShrink:0 }}>
                            Remove
                          </button>
                        </div>
                      );
                    })}
                  {slots.filter(s => s.date >= todayStr).length === 0 && <p style={{ color:"var(--g4)", fontSize:"0.82rem" }}>No upcoming slots.</p>}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Reschedule modal */}
        {rescheduleModal && (
          <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:100, padding:"1rem" }}>
            <div style={{ background:"var(--dark)", borderRadius:"1rem", padding:"2rem", maxWidth:"450px", width:"100%", border:"1px solid var(--g2)", boxShadow:"0 20px 60px rgba(0,0,0,0.5)" }}>
              <h2 style={{ fontSize:"1.4rem", color:"var(--white)", marginBottom:"0.3rem" }}>Reschedule Class</h2>
              <p style={{ color:"var(--g4)", fontSize:"0.8rem", marginBottom:"1.2rem" }}>
                Moving <strong style={{ color:"var(--white)" }}>{rescheduleModal.name}</strong>'s {rescheduleModal.level} from {formatDate(rescheduleModal.date)} at {rescheduleModal.time}
              </p>
              <label style={{ fontSize:"0.78rem", color:"var(--g5)", display:"block", marginBottom:"0.35rem" }}>Select a new slot:</label>
              <select value={rescheduleTarget} onChange={e => setRescheduleTarget(e.target.value)} style={{ ...sel, marginBottom:"1.2rem" }}>
                <option value="">-- Choose a slot --</option>
                {slots
                  .filter(s => s.id !== rescheduleModal.slotId && s.bookedBy.length < MAX_SPOTS && s.date >= todayStr)
                  .sort((a,b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))
                  .map(s => <option key={s.id} value={s.id}>{formatDate(s.date)} · {s.time} · {s.level} ({MAX_SPOTS - s.bookedBy.length} spots)</option>)}
              </select>
              <div style={{ display:"flex", gap:"0.7rem" }}>
                <button onClick={() => setRescheduleModal(null)} style={{ flex:1, padding:"0.7rem", borderRadius:"0.5rem", border:"1px solid var(--g2)", background:"transparent", cursor:"pointer", color:"var(--g5)", fontSize:"0.85rem" }}>Cancel</button>
                <button onClick={handleReschedule} disabled={!rescheduleTarget} style={{ flex:2, padding:"0.7rem", borderRadius:"0.5rem", background:rescheduleTarget?"var(--gold)":"var(--g2)", color:rescheduleTarget?"var(--black)":"var(--g4)", border:"none", cursor:rescheduleTarget?"pointer":"default", fontSize:"0.88rem", fontWeight:700 }}>
                  Confirm Reschedule
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

function Row({ label, value }) {
  return (
    <div style={{ display:"flex", justifyContent:"space-between", fontSize:"0.83rem" }}>
      <span style={{ color:"var(--g4)" }}>{label}</span>
      <span style={{ fontWeight:600, color:"var(--white)" }}>{value}</span>
    </div>
  );
}
